import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Podaj numer prania:");
        int nrUzytkownika = scanner.nextInt();

        Urzadzenie urzadzenie = new Urzadzenie();
        Pralka pralka = new Pralka();
        Odkurzacz odkurzacz = new Odkurzacz();

        pralka.ustawNrPrania(nrUzytkownika);

        odkurzacz.on();
        odkurzacz.on();
        odkurzacz.on();

        urzadzenie.wyswietl("Odkurzacz wyładowaSł się");
        odkurzacz.off();
    }
}