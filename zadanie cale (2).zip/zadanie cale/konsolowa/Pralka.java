public class Pralka extends Urzadzenie{
    private int nrProgramuPrania = 0;
    /*
    nazwa: ustawNrPrania
    opis: sprawdza czy wprowadzony numer prania jest w zakresie od 1 do 12 i jeśli jest to wyświetla komunikat w konsoli oraz ustawia nrProgramuPrania na numer podany w argumencie. Jeśli liczba jest z poza zakresu, to wyświetla komunikat o niepoprawnym numerze programu prania i ustawia numer programu prania na 0.
    parametry: komunikat, tekst który wyświetli się w konsoli
    zwracany typ i opis: całkowity, zwracany jest numer programu prania, lub 0 jeśli użytkownik podał liczbę spoza zakresu
    autor: 00000000000
    */
    public int ustawNrPrania(int numer){
        if(numer >= 1 && numer <= 12){
            nrProgramuPrania = numer;
           wyswietl("Program został ustawiony");
        }else{
            nrProgramuPrania = 0;
            System.out.println("Podano niepoprawny numer programu");
        }
        return nrProgramuPrania;
    }
}
