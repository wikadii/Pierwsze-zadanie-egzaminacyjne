public class Urzadzenie {
    /*
    nazwa: wyswietl
    opis: wyswietla w konsoli to co poda uzytkownik w argumencie
    parametry: komunikat, tekst który wyświetli się w konsoli
    zwracany typ i opis: "brak"
    autor: 00000000000
    */
    public void wyswietl(String komunikat){
        System.out.println(komunikat);
    }
}
