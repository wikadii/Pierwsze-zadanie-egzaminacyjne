public class Odkurzacz extends Urzadzenie{
    private boolean stanOdkurzacza = false;
    public void on(){
        if(stanOdkurzacza == false){
            stanOdkurzacza = true;
            wyswietl("Odkurzacz włączono");
        }
    }
    public void off(){
        if(stanOdkurzacza == true){
            stanOdkurzacza = false;
            wyswietl("Odkurzacz wyłączono");
        }
    }
}
