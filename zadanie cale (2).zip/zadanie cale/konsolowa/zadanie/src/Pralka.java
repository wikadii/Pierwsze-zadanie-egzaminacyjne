public class Pralka extends Urzadzenie{
    private int nrProgramuPrania = 0;
    public int ustawNrPrania(int numer){
        if(numer >= 1 && numer <= 12){
            nrProgramuPrania = numer;
           wyswietl("Program został ustawiony");
        }else{
            nrProgramuPrania = 0;
            System.out.println("Podano niepoprawny numer programu");
        }
        return nrProgramuPrania;
    }
}
