public class Urzadzenie {
    public void wyswietl(String komunikat){
        System.out.println(komunikat);
    }
}
