public class Odkurzacz extends Urzadzenie{
    private boolean stanOdkurzacza = false;
    /**
    nazwa: on
    opis: sprawdza jaki jest stan odkurzacza i jeśli jest wyłączony to wyświetla komunikat, że włącza się.
    parametry: "brak"
    autor: 00000000000
    */
    public void on(){
        if(stanOdkurzacza == false){
            stanOdkurzacza = true;
            wyswietl("Odkurzacz włączono");
        }
    }
    /*
    nazwa: off
    opis: sprawdza jaki jest stan odkurzacza i jeśli jest włączony to wyświetla komunikat, że wyłącza się.
    parametry: "brak"
    autor: 00000000000
    */
    public void off(){
        if(stanOdkurzacza == true){
            stanOdkurzacza = false;
            wyswietl("Odkurzacz wyłączono");
        }
    }
}
