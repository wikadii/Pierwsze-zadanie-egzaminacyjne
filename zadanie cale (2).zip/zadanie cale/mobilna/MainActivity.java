package com.example.mobilna;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    Button button, buttonOnOff;
    EditText editText;
    TextView textView, textViewOnOff;
    boolean isOn = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        button = findViewById(R.id.buttonApprove);
        editText = findViewById(R.id.editTextNumber);
        textView = findViewById(R.id.nrPraniaText);
        buttonOnOff = findViewById(R.id.buttonOnOff);
        textViewOnOff = findViewById(R.id.textViewOnOff);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String numString = editText.getText().toString();
                int num = Integer.parseInt(numString);
                if(num >= 1 && num <= 12){
                    textView.setText("Numer prania: " + numString);
                }
            }
        });

        buttonOnOff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!isOn){
                    buttonOnOff.setText("Wyłącz");
                    textViewOnOff.setText("Odkurzacz włączony");
                    isOn = true;
                }else{
                    buttonOnOff.setText("Włącz");
                    textViewOnOff.setText("Odkurzacz wyłączony");
                    isOn = false;
                }
            }
        });
    }
}